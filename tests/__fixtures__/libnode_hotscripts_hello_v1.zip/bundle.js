"use strict";

// ../../../../ZSpace/tmp4/hotscripts/functions/hello/index.js
var VERSION = "2.0.0";
exports.handler = async (event, context) => {
  console.log(`[Hello v${VERSION}] Event:`, JSON.stringify(event));
  return {
    statusCode: 200,
    body: {
      message: `Hot-updated v${VERSION}! No redeploy needed!`,
      version: VERSION,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      event
    }
  };
};
exports.VERSION = VERSION;
